import os
import sys
import json
import time
sys.path.append('c:/Users/CJH/OneDrive/Desktop/Haazir')

from backend.main import app, signup, login, get_searches, add_search, get_user_bookings
from backend.main import AuthRequest, SearchRequest, BookRequest
import asyncio

async def test_auth_flow():
    print("=== TESTING AUTHENTICATION BACKEND FLOW ===")
    
    test_username = f"test_user_{int(time.time())}@example.com"
    print(f"Using dynamic test username: {test_username}")
    
    # 1. Test Signup
    print("\n1. Running Signup...")
    signup_req = AuthRequest(username=test_username, password="securepassword123")
    signup_res = await signup(signup_req)
    print("Signup Response:", signup_res)
    assert signup_res["status"] == "success"
    
    # 2. Test Login
    print("\n2. Running Login...")
    login_req = AuthRequest(username=test_username, password="securepassword123")
    login_res = await login(login_req)
    print("Login Response:", login_res)
    assert login_res["status"] == "success"
    
    # 3. Test Add Search Query
    print("\n3. Adding Recent Search Query...")
    search_req = SearchRequest(query="electrician in G-11")
    search_res = await add_search(username=test_username, request=search_req)
    print("Add Search Response:", search_res)
    assert search_res["status"] == "success"
    assert "electrician in G-11" in search_res["searches"]
    
    # 4. Test Get Recent Searches
    print("\n4. Getting Recent Searches...")
    get_searches_res = await get_searches(username=test_username)
    print("Get Searches Response:", get_searches_res)
    assert "electrician in G-11" in get_searches_res["searches"]
    
    # 5. Test Get Bookings (Should be empty initially)
    print("\n5. Getting Bookings (Expected empty)...")
    bookings_res = await get_user_bookings(username=test_username)
    print("Bookings Response:", bookings_res)
    assert len(bookings_res["bookings"]) == 0
    
    print("\n=== ALL AUTH FLOW BACKEND TESTS PASSED SUCCESSFULLY! ===")

if __name__ == "__main__":
    asyncio.run(test_auth_flow())
