# Rebuild Haazir: Task Tracker

- [x] **Phase 0 — Project Setup & Scaffolding**
  - [x] Delete existing Node.js/React code
  - [x] Scaffolds FastAPI backend directory structure
  - [x] Setup Python environment and backend dependencies (`requirements.txt`)
  - [x] Scaffold Flutter application
  - [x] Create GCP and Firebase manual setup documentation
  - [x] Create dummy `.env.example`
- [x] **Phase 1 — Intent Agent**
  - [x] Implement IntentAgent using Google ADK and Gemini 2.0 Flash
  - [x] Integrate Geocoding API tool or fallback
  - [x] Create tests for multiple languages (Urdu, Roman Urdu, English)
- [x] **Phase 2 — Discovery Agent**
  - [x] Set up discovery logic checking mock provider dataset
  - [x] Integrate Google Distance Matrix API tool/mock fallback
  - [x] Implement distance-rating-availability multi-factor scoring
  - [x] Return top 3 providers with detailed reasoning
- [x] **Phase 3 — Booking Agent**
  - [x] Generate unique booking ID format (`HZR-YYYYMMDD-XXXX`)
  - [x] Implement Firestore booking write
  - [x] Implement Google Sheets logging via Sheets API
- [x] **Phase 4 — Follow-up Agent**
  - [x] Implement status tracking progression logic (Confirmed -> En Route -> Arrived -> Completed)
  - [x] Add Firestore live document updates
  - [x] Set up FCM push notification simulation payload
- [x] **Phase 5 — Antigravity Pipeline Assembly**
  - [x] Create root ADK Orchestrator combining Intent -> Discovery -> Booking -> Follow-up
  - [x] Build FastAPI `/agent` POST and `/trace` GET endpoints
  - [x] Verify backend end-to-end flow via test script
- [x] **Phase 6 — Flutter Mobile App**
  - [x] Screen 1: Home (multilingual input, categories, recent)
  - [x] Screen 2: Agent Thinking (visual progress timeline)
  - [x] Screen 3: Provider Results (AI recommendation badge and reasoning)
  - [x] Screen 4: Booking Confirmation (celebratory ticket-stub receipt & Google Sheets sync status)
  - [x] Screen 5: Active Booking Tracker (real-time Firestore stream status pipeline)
  - [x] Integration with backend endpoints
- [x] **Phase 7 — Demo Polish & Verification**
  - [x] Stress-test full end-to-end system
  - [x] Write updated `README.md`

- [x] **Phase 8 — UI Redesign (Google Stitch)**
  - [x] Update main.dart theme, color tokens, global components, shape, typography
  - [x] Redesign home_screen.dart (dual-language header, search, grid, recent list)
  - [x] Redesign agent_trace_screen.dart (timeline, pulsing loading state, animations)
  - [x] Redesign provider_results_screen.dart (filters, best match, slots bottom sheet)
  - [x] Redesign booking_confirmation_screen.dart (ticket stub, sync logs)
  - [x] Redesign active_booking_tracker.dart (map painter, progress tracker, feedback)
  - [x] Verify using flutter analyze

- [x] **Phase 9 — Authentication Flow (Sign Up & Login)**
  - [x] Add dependencies (`pubspec.yaml`) and configure services
  - [x] Implement `AuthService` with secure credential storage or dummy secure storage for demo
  - [x] Create `AuthWrapper` to manage session state and routing
  - [x] Create SignUpScreen (`signup_screen.dart`) and LoginScreen (`login_screen.dart`)
  - [x] Integrate user authentication state into `AgentProvider`
  - [x] Connect recent searches/bookings to user authentication
  - [x] Verify functionality and run code analysis


