# Sign Up & Login Feature Implementation Plan

## Goal Description
Add user authentication flow (sign‑up and login) to the Haazir mobile app. Users can register with email and/or phone number, credentials must be stored securely (e.g., using Flutter Secure Storage or Firebase Auth). After login, the app should display the user's recent searches/bookings retrieved from the backend.

## User Review Required
> [!IMPORTANT]
> The plan proposes using **Firebase Authentication** and **Flutter Secure Storage** for credential handling. If you prefer a different backend (e.g., custom API) or storage method, let me know.
>
> Also, confirm whether you want email‑only sign‑up, phone‑only, or both.

## Open Questions
- Which authentication provider should be used? (Firebase Auth, custom REST API, etc.)
- Should we enable social logins (Google, Apple) as well?
- Do you have an existing backend endpoint for retrieving recent searches, or should we add one?
- Preferred UI design style for the auth screens (dark mode, glassmorphism, etc.)?

## Proposed Changes
### 1. Dependencies
- Add `firebase_core`, `firebase_auth`, `flutter_secure_storage` to `pubspec.yaml`.
- Initialize Firebase in `main.dart`.

### 2. Auth Service Layer
- Create `lib/services/auth_service.dart` with methods:
  - `Future<User?> signUpWithEmail(String email, String password)`
  - `Future<User?> signInWithEmail(String email, String password)`
  - `Future<User?> signInWithPhone(String phoneNumber)` (optional)
  - `Future<void> signOut()`
  - Securely store the Firebase ID token using `FlutterSecureStorage`.

### 3. UI Screens
- **SignUpScreen** (`lib/screens/signup_screen.dart`)
  - Form fields: Email, Phone (optional), Password, Confirm Password.
  - Validation and error display.
- **LoginScreen** (`lib/screens/login_screen.dart`)
  - Email & Password fields (and optionally Phone).
  - “Forgot password?” link.
- **AuthWrapper** (`lib/screens/auth_wrapper.dart`)
  - Checks auth state on app start and navigates to HomeScreen or LoginScreen.

### 4. State Management
- Extend `AgentProvider` (or create `AuthProvider`) to expose `User? currentUser` and `bool isAuthenticated`.
- On successful sign‑in, fetch recent searches via existing API and store in provider (`recentSearches`).

### 5. Secure Storage
- Use `FlutterSecureStorage` to persist the auth token locally for auto‑login on app launch.
- Clear storage on sign‑out.

### 6. Recent Searches Integration
- After login, call `AgentService.getRecentSearches(userId)` and update `AgentProvider.recentSearches`.
- Modify HomeScreen to render recent searches from provider (already dynamic for bookings).

### 7. Navigation Updates
- Update `main.dart` routes to include `/signup`, `/login`, and protect `/home`.
- Ensure `AuthWrapper` is the entry widget.

### 8. Testing & Validation
- Write unit tests for `AuthService` methods.
- Add widget tests for sign‑up and login UI validation.
- Run `flutter analyze` and `flutter test`.

## Verification Plan
### Automated Tests
- `flutter test` for auth service unit tests.
- Widget tests for form validation and navigation.

### Manual Verification
- Install app on emulator/device.
- Create a new account, log out, log back in.
- Verify recent searches appear correctly on HomeScreen after login.
- Ensure credentials are not stored in plain text (inspect storage files).

---
*This plan awaits your feedback before proceeding with implementation.*
